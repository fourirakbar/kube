# chapter11-services-main
Contains infrastructure configuration for chapter 11 examples

## Build Status:
[![CircleCI](https://circleci.com/gh/building-microservices-with-go/chapter11-services-main.svg?style=svg)](https://circleci.com/gh/building-microservices-with-go/chapter11-services-main)
