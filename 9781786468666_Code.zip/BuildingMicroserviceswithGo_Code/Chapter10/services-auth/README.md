# chapter11-services-auth
Authentication service

### Build Status:
[![CircleCI](https://circleci.com/gh/building-microservices-with-go/chapter11-services-auth.svg?style=svg)](https://circleci.com/gh/building-microservices-with-go/chapter11-services-auth)

### Docker Image:
[https://hub.docker.com/r/buildingmicroserviceswithgo/auth](https://hub.docker.com/r/buildingmicroserviceswithgo/auth/)
