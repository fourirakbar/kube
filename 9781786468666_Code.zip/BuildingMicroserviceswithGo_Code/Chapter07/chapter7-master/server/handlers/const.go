package handlers

const (
	validationSuccess string = "kittenserver.validation.success"
	validationFailed  string = "kittenserver.validation.failed"
	helloworldSuccess string = "kittenserver.helloworld.success"
	helloworldFailed  string = "kittenserver.helloworld.failed"
	helloworldTiming  string = "kittenserver.helloworld.timing"
)
