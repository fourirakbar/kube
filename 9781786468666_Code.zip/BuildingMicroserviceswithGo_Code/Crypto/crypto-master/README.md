# crypto
[![CircleCI](https://circleci.com/gh/building-microservices-with-go/crypto.svg?style=svg)](https://circleci.com/gh/building-microservices-with-go/crypto)  

Helper package for public key cryptography
