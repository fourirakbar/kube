package data

type Kitten struct {
	Id     string
	Name   string
	Weight float32
}
