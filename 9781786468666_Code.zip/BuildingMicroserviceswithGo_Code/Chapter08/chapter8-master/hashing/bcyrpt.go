package hashing
