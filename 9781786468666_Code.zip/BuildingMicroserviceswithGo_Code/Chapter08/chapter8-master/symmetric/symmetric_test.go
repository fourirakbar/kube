package symmetric
